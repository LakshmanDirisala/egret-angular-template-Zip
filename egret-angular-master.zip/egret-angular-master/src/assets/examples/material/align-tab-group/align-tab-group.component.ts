import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-align-tab-group',
  templateUrl: './align-tab-group.component.html',
  styleUrls: ['./align-tab-group.component.scss']
})
export class AlignTabGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
