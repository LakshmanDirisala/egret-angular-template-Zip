import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-checkbox',
  templateUrl: './basic-checkbox.component.html',
  styleUrls: ['./basic-checkbox.component.scss']
})
export class BasicCheckboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
