import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appearance-form-field',
  templateUrl: './appearance-form-field.component.html',
  styleUrls: ['./appearance-form-field.component.scss']
})
export class AppearanceFormFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
