import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Notifications2Service {
  isPanelOpen: boolean = false;
  
  constructor() { }
}
