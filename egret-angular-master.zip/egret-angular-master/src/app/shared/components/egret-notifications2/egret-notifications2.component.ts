import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'egret-notifications2',
  templateUrl: './egret-notifications2.component.html',
  styleUrls: ['./egret-notifications2.component.scss']
})
export class EgretNotifications2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
