export interface User {
  id?: string;
  displayName?: string;
  role?: string
}