import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-example-view',
  templateUrl: './material-example-view.component.html'
})
export class MaterialExampleViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
