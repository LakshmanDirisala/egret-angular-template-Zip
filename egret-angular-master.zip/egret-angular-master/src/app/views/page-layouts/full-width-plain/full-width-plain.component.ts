import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-width-plain',
  templateUrl: './full-width-plain.component.html',
  styleUrls: ['./full-width-plain.component.scss']
})
export class FullWidthPlainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
