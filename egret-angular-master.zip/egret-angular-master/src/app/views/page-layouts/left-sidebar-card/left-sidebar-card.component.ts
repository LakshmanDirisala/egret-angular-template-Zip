import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-left-sidebar-card',
  templateUrl: './left-sidebar-card.component.html',
  styleUrls: ['./left-sidebar-card.component.scss']
})
export class LeftSidebarCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
